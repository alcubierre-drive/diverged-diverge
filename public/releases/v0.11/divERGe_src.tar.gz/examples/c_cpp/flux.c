#include <diverge.h>
#include <diverge_misc.h>
LINALG_IMPLEMENT

int main(int argc, char** argv) {
    diverge_init(&argc, &argv);
    diverge_compilation_status();
    mpi_loglevel_set(mpi_loglevel_vrb);

    int nk = 32,
        nkf = 1;
    double U = 3.0,
           V1 = 0.0;
    double ffdist = 0.01;

    diverge_model_t* m = diverge_model_init();
    m->lattice[0][0] = m->lattice[1][1] = m->lattice[2][2] = 1.0;
    m->positions[1][0] = m->positions[2][1] = m->positions[3][0] = m->positions[3][1] = 0.499;
    m->n_orb = 4;
    m->n_spin = m->SU2 = 1;
    m->nk[0] = m->nk[1] = nk;
    m->nkf[0] = m->nkf[1] = nkf;
    m->ibz_path[1][0] = m->ibz_path[2][0] = m->ibz_path[2][1] = 0.5;
    m->n_ibz_path = 4;

    double* dists = diverge_model_unique_distances(m, 5, 2);
    // for (double* d=dists; !qnan_isnan(*d); ++d) printf( "%.5e\n", *d);
    VECTOR_INIT(rs_hopping_t, hops);
    VECTOR_INIT(rs_vertex_t, verts);
    complex128_t phase = cexp(I*M_PI/4.);
    for (int i=-3; i<=3; ++i)
    for (int j=-3; j<=3; ++j)
    for (int o=0; o<m->n_orb; ++o)
    for (int p=0; p<m->n_orb; ++p) {
        claV3d_t diff = claV3d_add(claV3d_add(claV3d_scale(claV3d_map(m->lattice[0]),i),
                                              claV3d_scale(claV3d_map(m->lattice[1]),j)),
                                   claV3d_sub(claV3d_map(m->positions[p]),claV3d_map(m->positions[o])));
        double diff_nrm = claV3d_norm(diff);
        int dist0 = fabs(diff_nrm - dists[0]) < 1.e-4,
            dist1 = fabs(diff_nrm - dists[1]) < 1.e-4,
            dist2 = fabs(diff_nrm - dists[2]) < 1.e-4,
            dist3 = fabs(diff_nrm - dists[3]) < 1.e-4,
            dist4 = fabs(diff_nrm - dists[4]) < 1.e-4,
            dist5 = fabs(diff_nrm - dists[5]) < 1.e-4;
        if (dist0) {
            VECTOR_PUSH_BACK(verts, (rs_vertex_t){.chan='D', .R={i,j}, .o1=o, .o2=p, .V=U});
        } else if (dist1 || dist2) {

            int vert_1 = (o == 0 && p == 2) || (o == 2 && p == 0),
                vert_2 = (o == 1 && p == 3) || (o == 3 && p == 1),
                hori_1 = (o == 0 && p == 1) || (o == 1 && p == 0),
                hori_2 = (o == 2 && p == 3) || (o == 3 && p == 2);

            complex128_t hop = vert_1 ? (diff.v[1] > 0 ? phase : conj(phase)) :
                               vert_2 ? (diff.v[1] < 0 ? phase : conj(phase)) :
                               hori_1 ? (diff.v[0] < 0 ? phase : conj(phase)) :
                               hori_2 ? (diff.v[0] > 0 ? phase : conj(phase)) :
                                        0;
            hop *= dist2 ? 0.5 : 1.0;

            VECTOR_PUSH_BACK(hops, (rs_hopping_t){.R={i,j}, .o1=o,. o2=p, .t=hop});
            VECTOR_PUSH_BACK(verts, (rs_vertex_t){.chan='D', .R={i,j}, .o1=o, .o2=p, .V=V1});
        } else if (dist4) {
            VECTOR_PUSH_BACK(hops, (rs_hopping_t){.R={i,j}, .o1=o,. o2=p, .t=0.3});
        } else if (dist3 || dist5) {
            // VECTOR_PUSH_BACK(hops, (rs_hopping_t){.R={i,j}, .o1=o, .o2=p, .t=0.0});
        }
    }
    double gap = 0.0;
    VECTOR_PUSH_BACK(hops, (rs_hopping_t){.o1=0,.o2=0,.t=+gap});
    VECTOR_PUSH_BACK(hops, (rs_hopping_t){.o1=1,.o2=1,.t=-gap});
    VECTOR_PUSH_BACK(hops, (rs_hopping_t){.o1=2,.o2=2,.t=-gap});
    VECTOR_PUSH_BACK(hops, (rs_hopping_t){.o1=3,.o2=3,.t=+gap});
    m->hop = hops;
    m->n_hop = hops_sz;
    m->vert = verts;
    m->n_vert = verts_sz;
    free(dists);

    diverge_model_internals_common(m);
    diverge_model_set_filling(m, NULL, -1, 0.51);
    // TODO
    m->positions[1][0] = m->positions[2][1] = m->positions[3][0] = m->positions[3][1] = 0.0;

    // attach QGT
    index_t nkt[] = {-m->nk[0]*m->nkf[0], m->nk[1]*m->nkf[1], m->nk[2]*m->nkf[2]};
    index_t wb[] = {0,1};
    complex128_t* qgt_tensor = diverge_qgt_tensor(m, NULL, -1, nkt, wb, 2, 1);
    m->data = qgt_tensor;
    m->nbytes_data = sizeof*qgt_tensor * kdimtot(m->nk,m->nkf) * 9;

    diverge_model_output_conf_t oc = diverge_model_output_conf_defaults;
    oc.fatbands = 1;
    oc.npath = -1;
    oc.kf_ibz_path = 1;
    oc.E = 1;
    oc.U = 1;
    diverge_model_to_file_fg(m, __FILE__ "_mod.dvg", &oc);

    diverge_model_internals_tu(m, ffdist);
    diverge_flow_step_t* s = diverge_flow_step_init_any(m, "PCD");
    diverge_euler_t eu = diverge_euler_defaults;
    double vmax = 0.0;
    do {
        diverge_flow_step_euler(s, eu.Lambda, eu.dLambda);
        double pmax = diverge_flow_step_eigchan(s, 'p', 0),
               cmax = diverge_flow_step_eigchan(s, 'm', 0),
               dmax = diverge_flow_step_eigchan(s, 'h', 0);
        vmax = MAX(MAX(pmax,cmax),dmax);
        mpi_eprintf("%.5e %.5e %.5e %.5e\n", eu.Lambda, pmax, cmax, dmax);
    } while (diverge_euler_next(&eu, vmax));
    diverge_postprocess_conf_t pc = diverge_postprocess_conf_defaults;
    pc.tu_storing_relative = 1;
    pc.tu_storing_threshold = 0.0;
    pc.tu_which_solver_mode = 'B';
    pc.tu_channel_calc_project = -1;
    pc.tu_susceptibilities_bare = 1;
    diverge_postprocess_and_write_fg(s, __FILE__ "_out.dvg", &pc);
    diverge_flow_step_free(s);

    diverge_model_free(m);
    diverge_finalize();
}
