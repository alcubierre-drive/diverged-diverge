#include <diverge.h>
#include <diverge_misc.h>
LINALG_IMPLEMENT

diverge_model_t* kagome_model(index_t nk, index_t nkf);

int main(int argc, char** argv) {
    diverge_init(&argc, &argv);
    diverge_compilation_status();
    mpi_loglevel_set(mpi_loglevel_vrb);
    int nk = 96, nkf = 1;

    diverge_model_t* m = kagome_model(nk, nkf);
    diverge_model_internals_common(m);

    diverge_model_output_conf_t oc = diverge_model_output_conf_defaults;
    oc.npath = -1;
    oc.kf_ibz_path = 1;
    oc.E = 1;
    oc.kf = 1;
    diverge_model_to_file_fg(m, __FILE__ "_mod.dvg", &oc);

    diverge_model_internals_tu(m, 0.51);
    diverge_flow_step_t* s = diverge_flow_step_init_any(m, "PCD");
    diverge_euler_t eu = diverge_euler_defaults;
    double vmax = 0.0;
    do {
        diverge_flow_step_euler(s, eu.Lambda, eu.dLambda);
        double Pmax = diverge_flow_step_eigchan(s, 'p', INT_MIN),
               Cmax = diverge_flow_step_eigchan(s, 'm', INT_MIN),
               Dmax = diverge_flow_step_eigchan(s, 'h', INT_MIN);
        mpi_printf( "%.5e %.5e %.5e %.5e\n", eu.Lambda, Pmax, Cmax, Dmax );

        if (eu.Lambda < 1.e-1) break;
    } while (diverge_euler_next(&eu, vmax));

    diverge_flow_step_vertex_t vD = diverge_flow_step_vertex(s, 'h');
    FILE* f = fopen(__FILE__ "_vert.bin", "wb");
    fwrite(vD.ary, sizeof(*vD.ary), kdim(m->nk) * POW2(vD.n_orbff), f);
    fclose(f);

    index_t Num = kdim(m->nk),
            dim = vD.n_orbff;
    double* vals = malloc(Num*dim*sizeof*vals);
    complex128_t* vecs = malloc(Num*POW2(dim)*sizeof*vecs);
    memcpy(vecs, vD.ary, POW2(dim)*Num*sizeof*vecs);
    batched_eigen_r( NULL, -1, vecs, vals, dim, Num );
    index_t wb[4] = {0,1,2,3};
    complex128_t* qgt1234 = diverge_qgt_tensor(m, vecs, dim, NULL, wb, 4, 1);
    wb[0] = 4;
    wb[1] = 5;
    complex128_t* qgt56 = diverge_qgt_tensor(m, vecs, dim, NULL, wb, 2, 1);

    f = fopen(__FILE__ "_fuk.bin", "wb");
    fwrite(qgt1234, sizeof*qgt1234, Num*3*3, f);
    fwrite(qgt56, sizeof*qgt56, Num*3*3, f);
    fclose(f);

    free(qgt1234);
    free(qgt56);

    diverge_postprocess_conf_t pc = diverge_postprocess_conf_defaults;
    pc.tu_storing_relative = 1;
    pc.tu_storing_threshold = 0.0;
    diverge_postprocess_and_write_fg(s, __FILE__ "_out.dvg", &pc);
    diverge_flow_step_free(s);

    diverge_model_free(m);
    diverge_finalize();
}

diverge_model_t* kagome_model(index_t nk, index_t nkf) {
    diverge_model_t* m = diverge_model_init();
    m->nk[0] = m->nk[1] = nk;
    m->nkf[0] = m->nkf[1] = nkf;
    m->lattice[0][0] = 0.5*sqrt(3.);
    m->lattice[0][1] = -0.5;
    m->lattice[1][0] = 0.5*sqrt(3.);
    m->lattice[1][1] = 0.5;
    m->lattice[2][2] = 1.0;

    m->n_orb = 3;
    m->positions[0][0] = 0.5*sqrt(3.);
    m->positions[0][1] = 0.0;
    m->positions[1][0] = 0.5*sqrt(3.)-m->lattice[0][0]*0.5;
    m->positions[1][1] = -m->lattice[0][1]*0.5;
    m->positions[2][0] = 0.5*sqrt(3.)+m->lattice[1][0]*0.5;
    m->positions[2][1] = +m->lattice[1][1]*0.5;

    VECTOR_INIT(rs_hopping_t, hop);
    double* udist = diverge_model_unique_distances(m, 8, 2);

    for (int rx=-3; rx<=3; ++rx)
    for (int ry=-3; ry<=3; ++ry)
    for (int o1=0; o1<m->n_orb; ++ o1)
    for (int o2=0; o2<m->n_orb; ++ o2) {
        claV3d_t R = claM3d_vecmat( (claV3d_t){{rx,ry,0}}, claM3d_map(m->lattice[0]) );
        claV3d_t d = claV3d_sub(claV3d_map(m->positions[o2]),claV3d_map(m->positions[o1]));
        double dist = claV3d_norm(claV3d_add(R, d));
        if (fabs(dist - udist[1]) < 1e-6) {
            VECTOR_PUSH_BACK(hop, (rs_hopping_t){.R={rx,ry}, .o1=o1, .o2=o2, .s1=-1, .t=-1.0});
        }
    }

    m->vert = calloc(128, sizeof*m->vert);
    for (int o=0; o<3; ++o)
        m->vert[m->n_vert++] = (rs_vertex_t){ .chan='D', .o1=o, .o2=o, .s1=-1, .V=4.0 };

    m->n_hop = hop_sz;
    m->hop = hop;
    free(udist);

    m->n_ibz_path = 4;
    m->ibz_path[1][0] = 0.5;
    m->ibz_path[2][0] = 2./3.;
    m->ibz_path[2][1] = 1./3.;
    m->n_spin = m->SU2 = 1;

    if (diverge_model_validate(m)) diverge_mpi_exit(EXIT_FAILURE);
    return m;
}
