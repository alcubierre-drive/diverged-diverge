#!/usr/bin/env python3
# coding: utf-8

import numpy as np
import matplotlib.pyplot as plt
import diverge.output as do
import fancymaps as fm
ccmap = fm.complex_cmap_factory(fm.Cycl_wdiv4)

M = do.read('kagome2.c_mod.dvg')
P = do.read('kagome2.c_out.dvg')
NK = np.prod(M.nk)
nof = 15
V = np.fromfile('kagome2.c_vert.bin', dtype=np.complex128).reshape((NK,nof,nof))
F = np.fromfile('kagome2.c_fuk.bin', dtype=np.complex128).reshape((2,NK,3,3))

EE, UU = np.linalg.eigh(V.reshape((NK,15,15)))

UU2 = UU.reshape((M.nk[0],M.nk[1],nof,nof))
LCO_Vecs = np.zeros( (M.nk[0],M.nk[1],nof), dtype=np.complex128 )
LCO_Vecs[0,1,:] = UU2[0,1,:,1]
LCO_Vecs[1,0,:] = UU2[1,0,:,1]
LCO_Vecs[1,1,:] = UU2[1,1,:,1]
ky = 0
for kx in range(2,M.nk[0]):
    ovl = np.abs(LCO_Vecs[kx-1,ky,:] @ UU2[kx,ky,:,:4].conj())
    idx = np.argmax(ovl)
    if ovl[idx] < 0.9:
        print( ovl[idx], kx, ky )
    LCO_Vecs[kx,ky,:] = UU2[kx,ky,:,idx]
ky = 1
for kx in range(2,M.nk[0]):
    ovl = np.abs(LCO_Vecs[kx-1,ky,:] @ UU2[kx,ky,:,:4].conj())
    idx = np.argmax(ovl)
    if ovl[idx] < 0.9:
        print( ovl[idx], kx, ky )
    LCO_Vecs[kx,ky,:] = UU2[kx,ky,:,idx]
kx = 0
for ky in range(2,M.nk[0]):
    ovl = np.abs(LCO_Vecs[kx,ky-1,:] @ UU2[kx,ky,:,:4].conj())
    idx = np.argmax(ovl)
    if ovl[idx] < 0.9:
        print( ovl[idx], kx, ky )
    LCO_Vecs[kx,ky,:] = UU2[kx,ky,:,idx]
kx = 1
for ky in range(2,M.nk[0]):
    ovl = np.abs(LCO_Vecs[kx,ky-1,:] @ UU2[kx,ky,:,:4].conj())
    idx = np.argmax(ovl)
    if ovl[idx] < 0.9:
        print( ovl[idx], kx, ky )
    LCO_Vecs[kx,ky,:] = UU2[kx,ky,:,idx]
# now ky=(0,1) is filled. and we can always look to the bottom left.
for ky in range(2,M.nk[0]):
    for kx in range(2,M.nk[0]):
        ovl = np.abs(LCO_Vecs[kx-1,ky,:] @ UU2[kx,ky,:,:4].conj())
        idx = np.argmax(ovl)
        if ovl[idx] < 0.9:
            print( ovl[idx], kx, ky )
        LCO_Vecs[kx,ky,:] = UU2[kx,ky,:,idx]
LCO_Vert = np.einsum( 'xy o, xy p -> xy op', LCO_Vecs, LCO_Vecs.conj() )

devil_idx = np.where(np.abs(EE[:,1] - EE[:,2]) < 1.e-3)
plt.imshow( np.abs(EE[:,1]-EE[:,2]).reshape((96,96)), cmap='nipy_spectral_r', vmin=0 )
plt.show()
print( devil_idx )
# plt.imshow( ccmap(LCO_Vert.transpose((2,0,3,1)).reshape((nof*M.nk[0], -1))) )
# plt.show()
# print( LCO_Vert.shape )

plt.plot( do.bandstructure_xvals(M), -EE[M.kf_ibz_path[1]], marker='x' )
plt.show()
plt.imshow( ccmap(UU[48,:,2:3] @ UU[48,:,2:3].T.conj()) )
plt.figure()
plt.imshow( ccmap(UU[48,:,0:1] @ UU[48,:,0:1].T.conj()) )
plt.figure()
plt.imshow( ccmap(UU[48,:,1:2] @ UU[48,:,1:2].T.conj()) )
