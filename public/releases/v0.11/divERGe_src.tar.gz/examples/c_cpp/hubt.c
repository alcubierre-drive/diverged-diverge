#include <diverge.h>
#include <diverge_misc.h>
LINALG_IMPLEMENT

#include <diverge_flow_step_internal.h>
#include <tu/vertex_details.h>
#include <tu/flow_stepper_details.h>

typedef struct { double M[3][3]; } matrix_t;
static matrix_t rotation( double theta );
static matrix_t reflection( int axis );
static matrix_t matmul( matrix_t A, matrix_t B );
static int sgn2( int x );

void gloop_to_floop( char chan, complex128_t* buf, void* ctx ) {
    diverge_flow_step_t* s = ctx;
    tu_vertex_t* i = s->tu_step->internal_vertex;
    complex128_t* ibuf = chan == 'H' ? i->ph_bubble_int : i->pp_bubble_int;
    // printf( "%c: %p<-%p\n", chan, buf, ibuf );
    memcpy( buf, ibuf, POW2(POW2(i->n_spin)*i->n_orbff) * i->my_nk * sizeof*buf );
}

int main( int argc, char** argv ) {
    diverge_init( &argc, &argv );
    diverge_compilation_status();
    diverge_model_t* m = diverge_model_init();

    int nk = 20, nkf = 15;

    double tp = argc > 1 ? atof(argv[1]) : 0.3;
    double U  = argc > 2 ? atof(argv[2]) : 0.4;

    m->nk[0] = m->nk[1] = nk;
    m->nkf[0] = m->nkf[1] = nkf;
    m->lattice[0][0] = m->lattice[1][1] = m->lattice[2][2] = 1.0;
    m->n_orb = m->SU2 = m->n_spin = 1;
    m->ibz_path[1][0] = m->ibz_path[2][0] = m->ibz_path[2][1] = 0.5;
    m->n_ibz_path = 4;

    m->hop = diverge_mem_alloc_rs_hopping_t(12);
    m->hop[m->n_hop++] = (rs_hopping_t){.R={ 1, 0,0}, .t=-1};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={-1, 0,0}, .t=-1};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={ 0, 1,0}, .t=-1};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={ 0,-1,0}, .t=-1};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={ 1, 1,0}, .t=tp};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={-1, 1,0}, .t=tp};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={ 1,-1,0}, .t=tp};
    m->hop[m->n_hop++] = (rs_hopping_t){.R={-1,-1,0}, .t=tp};
    m->hop[m->n_hop++] = (rs_hopping_t){.t=4*tp};
    m->vert = diverge_mem_alloc_rs_vertex_t(12);
    m->vert[m->n_vert++] = (rs_vertex_t){.chan='D', .R={0,0,0}, .V=U};
    mpi_loglevel_set(mpi_loglevel_vrb);

    m->n_sym = 8;
    m->orb_symmetries = (complex128_t*)diverge_mem_alloc_complex128_t(m->n_sym);
    for (int i=0; i<m->n_sym; ++i) {
        m->orb_symmetries[i] = 1;
        matrix_t S;
        switch (i) {
            case 0: case 1: case 2: case 3: S = rotation(i*90); break;
            case 4: case 5: S = reflection(i%2); break;
            case 6: case 7: S = matmul(matmul(rotation(sgn2(i)*45),reflection(1)),
                                       rotation(-sgn2(i)*45)); break;
            default: break;
        }
        memcpy( m->rs_symmetries[i][0], S.M[0], sizeof(double)*9 );
    }

    m->orb_symmetries = NULL;
    m->n_sym = 0;
    diverge_model_validate(m);
    diverge_model_internals_common(m);
    diverge_model_internals_tu(m, 1.51);

    tu_formfactor_map_t* ffmap = tu_formfactor_map_init(m);
    for (int Rx=-1; Rx<=1; Rx+=2)
    for (int Ry=-1; Ry<=1; Ry+=2) {
        m->vert[m->n_vert++] = (rs_vertex_t){ .R={0,0,0},
            .o1=tu_formfactor_map_get(ffmap,Rx,Ry,0,0,0).t,
            .o2=tu_formfactor_map_get(ffmap, 0, 0,0,0,0).t,
            .V=0.1
        };
        m->vert[m->n_vert++] = (rs_vertex_t){ .R={0,0,0},
            .o1=tu_formfactor_map_get(ffmap, 0, 0,0,0,0).t,
            .o2=tu_formfactor_map_get(ffmap,Rx,Ry,0,0,0).t,
            .V=0.1
        };
    }
    tu_formfactor_map_free(ffmap);

    m->vert[m->n_vert++] = (rs_vertex_t){.chan='Z', .R={0,0,0}, .V=U};

    // output
    diverge_model_output_conf_t oc = diverge_model_output_conf_defaults;
    oc.kc_ibz_path = oc.kf_ibz_path = 1;
    mpi_usr_printf( "model@%s\n", diverge_model_to_file_finegrained(m, __FILE__ "_mod.dvg", &oc) );

    // flow step & integrate
    diverge_flow_step_t* f = diverge_flow_step_init(m, "tu", "PCD");
    diverge_flow_step_t* g = diverge_flow_step_init(m, "tu", "PCD");
    g->tu_step->loop_func = gloop_to_floop;
    g->tu_step->loop_func_ctx = f;

    index_t qpts[] = {0};
    vertex_storage_t* v = vertex_storage_init(f, 'p', qpts, 1);

    diverge_euler_t eu = diverge_euler_defaults;
    eu.maxvert = 10;
    eu.maxiter = 20;
    double vmax = 0.0;
    do {
        diverge_flow_step_euler( f, eu.Lambda, eu.dLambda );
        diverge_flow_step_euler( g, eu.Lambda, eu.dLambda );
        vertex_storage_lsnap(v, eu.Lambda);
        double pmax = diverge_flow_step_eigchan( f, 'p', 1 ),
               cmax = diverge_flow_step_eigchan( f, 'm', 1 ),
               dmax = diverge_flow_step_eigchan( f, 'h', 1 );
        vmax = MAX(MAX(fabs(pmax),fabs(cmax)),fabs(dmax));
        mpi_printf( "%.5e %.5e %.5e %.5e\n", eu.Lambda, pmax, cmax, dmax );
    } while (diverge_euler_next(&eu, vmax));

    vertex_storage_to_file(v, __FILE__ "_vert.dvg");

    // post-process
    diverge_postprocess_conf_t pc = diverge_postprocess_conf_defaults;
    pc.tu_susceptibilities_full = true;
    pc.tu_susceptibilities_bare = true;
    pc.tu_channel_calc_project = -1;
    pc.tu_which_solver_mode = 'B';
    pc.tu_storing_threshold = 0.1;
    pc.tu_storing_relative = 1;
    // diverge_postprocess_conf_tu_storing_threshold_qrelative(0.9);
    diverge_postprocess_and_write_finegrained( f, __FILE__ "_out.dvg", &pc );

    // cleanup
    diverge_flow_step_free(f);
    diverge_flow_step_free(g);
    diverge_model_free(m);
    diverge_finalize();

    return 0;
}

// some helper functions because we're using C
static matrix_t rotation( double theta ) {
    double theta_rad = M_PI/180.*theta;
    matrix_t r = {0};
    r.M[2][2] = 1;
    r.M[0][0] = r.M[1][1] = cos(theta_rad);
    r.M[0][1] = sin(theta_rad);
    r.M[1][0] = -r.M[0][1];
    return r;
}
static matrix_t reflection( int axis ) {
    matrix_t r = {0};
    r.M[0][0] = r.M[1][1] = r.M[2][2] = 1.0;
    r.M[axis][axis] *= -1;
    return r;
}
static matrix_t matmul( matrix_t A, matrix_t B ) {
    matrix_t r = {0};
    for (int i=0; i<3; ++i)
    for (int j=0; j<3; ++j)
    for (int k=0; k<3; ++k)
        r.M[i][j] += A.M[i][k] * B.M[k][j];
    return r;
}
/* static void matrix_print( matrix_t M ) { */
/*     mpi_usr_printf( "[[%5.2f %5.2f %5.2f]" */
/*                     " [%5.2f %5.2f %5.2f]" */
/*                     " [%5.2f %5.2f %5.2f]]\n", */
/*             M.M[0][0], M.M[0][1], M.M[0][2], */
/*             M.M[1][0], M.M[1][1], M.M[1][2], */
/*             M.M[2][0], M.M[2][1], M.M[2][2] ); */
/* } */
static int sgn2( int x ) {
    if (x < 0) x *= -1;
    return -1 + (x % 2)*2;
}
