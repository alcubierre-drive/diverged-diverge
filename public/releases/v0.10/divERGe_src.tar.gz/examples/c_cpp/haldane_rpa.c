#include <diverge.h>
#include <diverge_misc.h>

LINALG_IMPLEMENT
#define ZERO( x ) (fabs(x) < 1e-6)

static diverge_model_t* haldane_model( int nk, int nkf, double M, double V, double Vp );

int main( int argc, char** argv ) {
    diverge_init( &argc, &argv );
    diverge_compilation_status();

    int nk = 24, nkf = 1;
    double M = 0.1, V = 3.0, Vp = 1.0;
    diverge_model_t* m = haldane_model( nk, nkf, M, V, Vp );
    diverge_model_internals_common( m );
    diverge_model_set_chempot( m, NULL, -1, -2.5 );

    index_t nks[] = {-m->nk[0]*m->nkf[0], m->nk[1]*m->nkf[1], m->nk[2]*m->nkf[2]};
    double* berry = diverge_fukui( m, NULL, -1, nks );
    double chern = 0.0;
    for (index_t i=0; i<kdimtot(m->nk,m->nkf); ++i) chern += berry[IDX3(i,0,2, m->n_orb,3)];
    free( berry );
    mpi_scc_printf( "found chern number of lower band ::: C=%.2f\n", chern );

    diverge_model_output_conf_t oc = diverge_model_output_conf_defaults;
    oc.npath = -1;
    oc.kf_ibz_path = 1;
    oc.kf = 1;
    oc.E = 1;
    diverge_model_to_file_fg( m, __FILE__ "_mod.dvg", &oc );

    diverge_model_internals_tu( m, 0.71 );
    diverge_flow_step_t* s = diverge_flow_step_init_any( m, "PCD" );
    diverge_flow_step_attach_rpa( s, NULL, -1 );
    diverge_euler_t eu = diverge_euler_defaults;
    eu.Lambda_min = 1.e-2;
    double vmax = 0.0;
    double cmax[3] = {0,0,0};
    do {
        diverge_flow_step_euler( s, eu.Lambda, eu.dLambda );
        diverge_flow_step_chanmax( s, cmax );
        diverge_flow_step_vertmax( s, &vmax );
        printf( "%.5e %.5e %.5e %.5e\n", eu.Lambda, cmax[0], cmax[1], cmax[2] );
    } while (diverge_euler_next(&eu, vmax));

    diverge_postprocess_conf_t pc = diverge_postprocess_conf_defaults;
    // strcpy( pc.tu_rpa_chans, "c" );
    diverge_postprocess_and_write_fg( s, __FILE__ "_out.dvg", &pc );

    diverge_flow_step_free( s );
    diverge_model_free( m );
    diverge_finalize();
}

static diverge_model_t* haldane_model( int nk, int nkf, double M, double V, double Vp ) {
    diverge_model_t* m = diverge_model_init();
    m->nk[0] = m->nk[1] = nk;
    m->nkf[0] = m->nkf[1] = nkf;
    m->SU2 = 0;
    m->n_spin = 1;
    m->n_orb = 2;

    m->lattice[0][0] = m->lattice[2][2] = 1.0;
    m->lattice[1][0] = cos(2.*M_PI/3.);
    m->lattice[1][1] = sin(2.*M_PI/3.);

    claV3d_t a1 = claV3d_map( m->lattice[0] ),
             a2 = claV3d_map( m->lattice[1] );

    claV3d_t o1 = claV3d_add(claV3d_scale(a1,1./3.), claV3d_scale(a2,2./3.)),
             o2 = claV3d_add(claV3d_scale(a1,2./3.), claV3d_scale(a2,1./3.));

    claV3d_rmap( o1, m->positions[0] );
    claV3d_rmap( o2, m->positions[1] );

    double* dists = diverge_model_unique_distances( m, 4, 2 );
    VECTOR_INIT( rs_hopping_t, hop );
    VECTOR_INIT( rs_vertex_t, vert );

    for (int i=-2; i<=2; ++i)
    for (int j=-2; j<=2; ++j)
    for (int o=0; o<2; ++o)
    for (int p=0; p<2; ++p) {
        claV3d_t O = claV3d_sub( claV3d_map(m->positions[p]), claV3d_map(m->positions[o]) );
        claV3d_t D = claV3d_add( claV3d_add( claV3d_scale(a1,i), claV3d_scale(a2,j) ), O );

        double dist = claV3d_norm( D );
        if ZERO(dist - dists[1]) {
            VECTOR_PUSH_BACK( hop, (rs_hopping_t){ .R={i,j}, .o1=o, .o2=p, .t=1 } );
            VECTOR_PUSH_BACK( vert, (rs_vertex_t){ .chan='D', .R={i,j}, .o1=o, .o2=p, .V=V } );
        } else if ZERO(dist - dists[2]) {
            index_t phi = lroundl( fmod( carg( D.v[0] + I * D.v[1] ) / (2.*M_PI) + 1., 1. ) * 6. );
            VECTOR_PUSH_BACK( hop, (rs_hopping_t){ .R={i,j}, .o1=o, .o2=p,
                    .t=(o?1.:-1.) * (phi%2?1:-1.) * I * M } );
            VECTOR_PUSH_BACK( vert, (rs_vertex_t){ .chan='D', .R={i,j}, .o1=o, .o2=p, .V=Vp } );
        }
    }
    free( dists );

    m->hop = hop;
    m->n_hop = hop_sz;

    m->vert = vert;
    m->n_vert = vert_sz;

    m->ibz_path[1][0] = 0.5;
    m->ibz_path[2][0] = m->ibz_path[2][1] = 1./3.;
    m->n_ibz_path = 4;

    return m;
}

