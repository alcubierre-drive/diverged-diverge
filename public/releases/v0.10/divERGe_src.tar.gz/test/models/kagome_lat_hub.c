#include "all.h"
#include "../../src/diverge.h"
#include "../../src/misc/linalg.h"
LINALG_IMPLEMENT

#include <assert.h>

#ifndef DIVERGE_SKIP_TESTS

diverge_model_t* gen_kagome_model( index_t nkx, index_t nky, double U ,
        double V , double VC , double VP, index_t nsym ) {
    diverge_model_t* mod = diverge_model_init();
    sprintf(mod->name, "Kagome");

    assert(nkx == nky);
    (void)nky;
    // initialize lattice and number of momentum points - is 2d
    mod->nk[0] = mod->nk[1] = nkx;
    mod->nkf[0] = mod->nkf[1] = 1;
    mod->lattice[0][0] = 0.5*sqrt(3.);
    mod->lattice[0][1] = -0.5;
    mod->lattice[1][0] = 0.5*sqrt(3.);
    mod->lattice[1][1] = 0.5;
    mod->lattice[2][2] = 1.0;


    // initialize positions and number of orbitals
    mod->n_orb = 3;
    mod->SU2 = true;
    mod->n_spin = 1;
    mod->n_hop = 0;
    mod->positions[0][0] = 0.5*sqrt(3.);
    mod->positions[0][1] = 0.0;
    mod->positions[1][0] = 0.5*sqrt(3.)-mod->lattice[0][0]*0.5;
    mod->positions[1][1] = -mod->lattice[0][1]*0.5;
    mod->positions[2][0] = 0.5*sqrt(3.)+mod->lattice[1][0]*0.5;
    mod->positions[2][1] = +mod->lattice[1][1]*0.5;

    // generate nearest neighbor hoppings
    VECTOR_INIT(rs_hopping_t, hop);
    rs_hopping_t helper;
    helper.s1 = 0, helper.s2 = 0;
    helper.t = 1.0;
    claV3d_t r1 = claV3d_map(mod->lattice[0]), r2 = claV3d_map(mod->lattice[1]);

    // distance definition is  c^{\dagger}_{o_2+R}c_{o_1}
    for(int rx = -3; rx < 4; ++rx)
    for(int ry = -3; ry < 4; ++ry) {
        for(int o1 = 0; o1 < mod->n_orb; ++ o1)
        for(int o2 = 0; o2 < mod->n_orb; ++ o2) {
            claV3d_t p1 = claV3d_map(mod->positions[o1]), p2 = claV3d_map(mod->positions[o2]);
            claV3d_t bond = claV3d_add(claV3d_sub(p2,p1),
                    claV3d_add(claV3d_scale(r1,rx),claV3d_scale(r2,ry)));
            if (fabs(claV3d_norm(bond) - 0.5) < 1e-7) {
                helper.o1 = o1, helper.o2 = o2, helper.R[0]=rx,helper.R[1]=ry;
                VECTOR_PUSH_BACK(hop, helper);
            }
        }
    }
    mod->hop = hop;
    mod->n_hop = hop_sz;
    mpi_usr_printf( "using %li hopping elements\n", mod->n_hop );

    //generate interaction vertex - density density type
    VECTOR_INIT(rs_vertex_t, Rvert);
    rs_vertex_t helperv;
    helperv.chan = 'D';
    // s1 == -1 means that the interaction can be constructed by using the
    // crossing relations
    helperv.s1 = -1, helperv.R[0] = 0, helperv.R[1] = 0, helperv.R[2] = 0;
    for (int rx = -2; rx < 3; ++rx)
    for (int ry = -2; ry < 3; ++ry) {
        for (int o1 = 0; o1 < mod->n_orb; ++ o1)
        for (int o2 = 0; o2 < mod->n_orb; ++ o2) {
            claV3d_t p1 = claV3d_map(mod->positions[o1]), p2 = claV3d_map(mod->positions[o2]);
            claV3d_t bond = claV3d_add(claV3d_sub(p2,p1),
                    claV3d_add(claV3d_scale(r1,rx),claV3d_scale(r2,ry)));
            if (fabs(claV3d_norm(bond) - 0.5) < 1e-7) {
                helperv.o1 = o1, helperv.o2 = o2, helperv.R[0]=rx, helperv.R[1]=ry;
                helperv.V = V;
                VECTOR_PUSH_BACK(Rvert, helperv);
            }
            if (claV3d_norm(bond) < 1e-7) {
                helperv.o1 = o1, helperv.o2 = o2, helperv.R[0]=rx, helperv.R[1]=ry;
                helperv.V = U;
                VECTOR_PUSH_BACK(Rvert, helperv);
            }
        }
    }

    helperv.s1 = -1, helperv.R[0] = 0, helperv.R[1] = 0, helperv.R[2] = 0;
    for (int rx = -2; rx < 3; ++rx)
    for (int ry = -2; ry < 3; ++ry) {
        for (int o1 = 0; o1 < mod->n_orb; ++ o1)
        for (int o2 = 0; o2 < mod->n_orb; ++ o2) {
            claV3d_t p1 = claV3d_map(mod->positions[o1]), p2 = claV3d_map(mod->positions[o2]);
            claV3d_t bond = claV3d_add(claV3d_sub(p2,p1),
                    claV3d_add(claV3d_scale(r1,rx),claV3d_scale(r2,ry)));
            if (fabs(claV3d_norm(bond) - 0.5) < 1e-7) {
                helperv.o1 = o1, helperv.o2 = o2, helperv.R[0]=rx, helperv.R[1]=ry;
                helperv.V = VC;
                helperv.chan = 'C';
                VECTOR_PUSH_BACK(Rvert, helperv);
                helperv.V = VP;
                helperv.chan = 'P';
                VECTOR_PUSH_BACK(Rvert, helperv);
            }
        }
    }

    mod->vert = Rvert;
    mod->n_vert = Rvert_sz;
    mpi_usr_printf( "using %li vertex elements\n", mod->n_vert );

    mod->n_ibz_path = 4;
    mod->ibz_path[1][0] = 0.5;
    mod->ibz_path[2][0] = 0.5;
    mod->ibz_path[2][1] = 0.5;

    site_descr_t sites[3] = {0};
    sites[0].n_functions = 1;
    sites[0].amplitude[0] = 1.;
    sites[0].function[0] = orb_s;
    sites[1].n_functions = 1;
    sites[1].amplitude[0] = 1.;
    sites[1].function[0] = orb_s;
    sites[2].n_functions = 1;
    sites[2].amplitude[0] = 1.;
    sites[2].function[0] = orb_s;

    mod->orb_symmetries = calloc(20*POW2(mod->n_orb*mod->n_spin),sizeof(complex128_t));
    index_t symsize = POW2(mod->n_orb*mod->n_spin);
    sym_op_t curr_symm[3] = {0};

    curr_symm[0].type = 'R'; curr_symm[0].normal_vector[0] = 0.;
    curr_symm[0].normal_vector[1] = 0.;curr_symm[0].normal_vector[2] = 1.;
    curr_symm[1].type = 'M'; curr_symm[1].normal_vector[0] = 1.;    sites[2].amplitude[0] = 1.;
    sites[2].function[0] = orb_s;

    curr_symm[0].type = 'R'; curr_symm[0].normal_vector[0] = 0.;
    curr_symm[0].normal_vector[1] = 0.;curr_symm[0].normal_vector[2] = 1.;
    curr_symm[1].type = 'M'; curr_symm[1].normal_vector[0] = 1.;

    curr_symm[1].normal_vector[1] = 0.;curr_symm[1].normal_vector[2] = 0.;
    curr_symm[2].type = 'R'; curr_symm[2].normal_vector[0] = 0.;
    curr_symm[2].normal_vector[1] = 0.;curr_symm[2].normal_vector[2] = 1.;
    int cnt;
    // C6
    for(cnt = 0; cnt < 6; ++cnt) {
        curr_symm[0].angle = 60*cnt;
        diverge_generate_symm_trafo(mod->n_spin,sites, mod->n_orb,
                curr_symm, 1,&(mod->rs_symmetries[cnt][0][0]),mod->orb_symmetries+cnt*symsize);
    }

    // mirror planes
    for(cnt = 6; cnt < 9; ++cnt) {
        curr_symm[0].angle = -120*(cnt-6);
        curr_symm[2].angle = 120*(cnt-6);
        diverge_generate_symm_trafo(mod->n_spin,sites, mod->n_orb,
                curr_symm, 3,&(mod->rs_symmetries[cnt][0][0]),mod->orb_symmetries+cnt*symsize);
    }
    curr_symm[1].type = 'M'; curr_symm[1].normal_vector[0] = 0.;
    curr_symm[1].normal_vector[1] = 1.;
    for(cnt = 9; cnt < 12; ++cnt) {
        curr_symm[0].angle = -120*(cnt-9);
        curr_symm[2].angle = 120*(cnt-9);
        diverge_generate_symm_trafo(mod->n_spin,sites, mod->n_orb,
                curr_symm, 3,&(mod->rs_symmetries[cnt][0][0]),mod->orb_symmetries+cnt*symsize);
    }
    mod->n_sym = cnt;
    if (nsym == 0)
        mod->n_sym = 0;

    // check that mod is set up properly
    if (diverge_model_validate( mod ))
        diverge_mpi_exit( EXIT_FAILURE );
    // initialize internals
    diverge_model_internals_common( mod );

    return mod;
}

#endif // DIVERGE_SKIP_TESTS
